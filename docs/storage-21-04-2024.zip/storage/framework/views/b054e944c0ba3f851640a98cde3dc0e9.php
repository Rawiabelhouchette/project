<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag; ?>
<?php foreach($attributes->onlyProps(['title', 'category', 'items', 'selectedItems', 'icon', 'filterModel']) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $attributes = $attributes->exceptProps(['title', 'category', 'items', 'selectedItems', 'icon', 'filterModel']); ?>
<?php foreach (array_filter((['title', 'category', 'items', 'selectedItems', 'icon', 'filterModel']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>

<div>
    <div class="widget-boxed padd-bot-10 mrg-bot-10">
        <div class="widget-boxed-header">
            <h4 class="theme-cl-blue"><i class="<?php echo e($icon); ?> padd-r-10 theme-cl-blue"></i><?php echo e($title); ?>

        </div>
        <div class="widget-boxed-body padd-top-10">
            <div class="side-list">
                <input type="search" wire:model='<?php echo e($filterModel); ?>' style="height: 40px; border-radius: 5px;" class="form-control" id="search-<?php echo e($category); ?>" placeholder="Rechercher" onkeyup="filterList('<?php echo e($category); ?>')">
                <ul class="price-range" id="list-<?php echo e($category); ?>s" style="min-height: 100px; max-height: 273px; overflow-y: auto;">
                    <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li style="padding: 5px;  display: none;" wire:key='<?php echo e($category); ?>-<?php echo e($item['value']); ?>'>
                            <span class="custom-checkbox d-block padd-top-0">
                                <input id="check-<?php echo e($item['value']); ?>" type="checkbox" value="<?php echo e($item['value']); ?>" wire:change='changeState("<?php echo e($item['value']); ?>", "<?php echo e($category); ?>")' <?php echo e(in_array($item['value'], $selectedItems) ? 'checked' : null); ?>> 
                                <label for="check-<?php echo e($item['value']); ?>" style="font-weight: normal;"><?php echo e($item['value']); ?></label>
                            </span>
                            <span class="theme-cl" style="float: right;">
                                <?php echo e($item['count']); ?> &nbsp;
                            </span>
                        </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                    <p id="no-<?php echo e($category); ?>-results" class="text-center" style="display: none;">Aucun résultat</p>
                </ul>
            </div>
        </div>
    </div>
</div>
<?php /**PATH /home/cp1820222p42/public_html/midjo/resources/views/components/public/filter-view.blade.php ENDPATH**/ ?>