<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag; ?>
<?php foreach($attributes->onlyProps(['galerie', 'couverture']) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $attributes = $attributes->exceptProps(['galerie', 'couverture']); ?>
<?php foreach (array_filter((['galerie', 'couverture']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>

<div id="modal-gallery" class="modal fade mrg-top-40" tabindex="-1" role="dialog" aria-labelledby="myModalLabel3" aria-hidden="true" style="z-index: 9999 !important;" data-backdrop="static" data-keyboard="false">
    <div class="modal-dialog modal-lg" role="document" style="width: 80vw; max-width: 80vw;">
        <div class="modal-content">

            <div class="modal-header">
                <h4 id="modalLabel3" class="modal-title">Galérie (<?php echo e(count($galerie) + 1); ?> images)</h4>
                <button type="button" class="m-close" data-dismiss="modal" aria-label="Close">
                    <i class="ti-close"></i>
                </button>
            </div>

            <div class="modal-body padd-top-0" style="max-height: 80vh; overflow-y: auto;">
                <div class="row padd-0">
                    <div class="col-xs-12 col-md-3 col-lg-3">
                        <div class="listing-shot grid-style">
                            <div style="display: flex; justify-content: center; align-items: center;">
                                <a id="image-<?php echo e($couverture->id); ?>" data-fancybox="gallery" href="<?php echo e(asset('storage/' . $couverture->chemin)); ?>">
                                    <img class="listing-shot-img" src="<?php echo e(asset('storage/' . $couverture->chemin)); ?>" class="img-responsive" alt="">
                                </a>
                            </div>
                        </div>
                    </div>
                    <?php $__currentLoopData = $galerie; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-xs-12 col-md-3 col-lg-3">
                            <div class="listing-shot grid-style">
                                <div style="display: flex; justify-content: center; align-items: center;">
                                    <a id="image-<?php echo e($image->id); ?>" data-fancybox="gallery" href="<?php echo e(asset('storage/' . $image->chemin)); ?>">
                                        <img class="listing-shot-img" src="<?php echo e(asset('storage/' . $image->chemin)); ?>" class="img-responsive" alt="">
                                    </a>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
    </div>
</div>
<?php /**PATH /home/cp1820222p42/public_html/midjo/resources/views/public/gallery.blade.php ENDPATH**/ ?>