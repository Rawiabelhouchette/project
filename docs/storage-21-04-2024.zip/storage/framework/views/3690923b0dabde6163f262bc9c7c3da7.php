<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag; ?>
<?php foreach($attributes->onlyProps(['caracteristiques']) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $attributes = $attributes->exceptProps(['caracteristiques']); ?>
<?php foreach (array_filter((['caracteristiques']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>

<div class="row">
    <?php $__empty_1 = true; $__currentLoopData = $caracteristiques; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <div class="col-md-4 col-xs-12 mrg-bot-5 text-center padd-bot-5">
            <?php echo e($key); ?> <br>
            <strong class="theme-cl"><?php echo e($value); ?></strong>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <div class="col-md-12">
            Aucune information disponible
        </div>
    <?php endif; ?>
</div>
<?php /**PATH /home/cp1820222p42/public_html/midjo/resources/views/components/public/show/default.blade.php ENDPATH**/ ?>