<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag; ?>
<?php foreach($attributes->onlyProps(['title']) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $attributes = $attributes->exceptProps(['title']); ?>
<?php foreach (array_filter((['title']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>

<section class="detail-section" style="background:url(assets_client/img/banner/image-2.jpg);" data-overlay="6">
    <div class="overlay" style="background-color: rgb(36, 36, 41); opacity: 0.5;"></div>
    <div class="profile-cover-content">
        <div class="container">
            <div class="center">
                <h3 style="color: white;"><?php echo e($title); ?></h3>
            </div>
        </div>
    </div>
</section>
<?php /**PATH /home/cp1820222p42/public_html/midjo/resources/views/public/user/title-banner.blade.php ENDPATH**/ ?>