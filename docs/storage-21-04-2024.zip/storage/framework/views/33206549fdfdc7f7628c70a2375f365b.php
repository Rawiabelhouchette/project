<?php $__env->startSection('dashboard', 'active'); ?>

<?php $__env->startSection('content'); ?>
    <div class="row bg-title" style="padding-top: 20px; margin-bottom: 10px;">
        <div class="col-lg-6 col-md-10 col-sm-6 col-xs-12">
            <ol class="breadcrumb" style="text-align: left;">
                <li class="active"><a href="#">Dashboard</a></li>
            </ol>
        </div>
    </div>
    <div id="page-inner" class="mrg-top-0 padd-top-0" style="margin-top: 0px !important; padding-top: 0px !important;">
        <div class="bott-wid">
            <div class="listing-shot mrg-bot-20">
                <div class="listing-shot-info">
                    <span class="text-center font-16 text-justify">
                        
                    </span>
                </div>
            </div>
            
        </div>
    </div>
    
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script>
        // $(document).ready(function() {
        //     setInterval(function() {
        //         // Active users
        //         $.ajax({
        //             url: $('#metaData').data('connexion'),
        //             type: "GET",
        //             success: function(data) {
        //                 $('#connexions').html(data);
        //             }
        //         });

        //         // Consultations
        //         $.ajax({
        //             url: $('#metaData').data('consultation'),
        //             type: "GET",
        //             success: function(data) {
        //                 $('#consultations').html(data);
        //             }
        //         });
        //     }, 10000);
        // } );
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.admin.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/cp1820222p42/public_html/midjo/resources/views/admin/dashboard.blade.php ENDPATH**/ ?>