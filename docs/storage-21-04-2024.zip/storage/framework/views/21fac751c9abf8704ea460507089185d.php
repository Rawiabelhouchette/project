<div>
    <style>
        .theme-cl-blue {
            color: #006ce4 !important;
        }
    </style>
    <!-- ================ Listing In Grid Style ======================= -->
    <section class="padd-top-20">
        <div class="container">
            <div class="row">
                <!-- Start Sidebar -->
                <div class="col-md-4 col-sm-12">
                    <h4 class="text-center mrg-bot-15 theme-cl-blue">Filtrer vos recherches</h4>

                    <!--[if BLOCK]><![endif]--><?php if($type || $ville || $quartier || $entreprise): ?>
                        <p class="text-center">
                            <a href="javascript:void(0)" class="reset-filters" wire:click='resetFilters'>
                                Effacer tous les filtres
                            </a>
                        </p>
                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

                    <div class="sidebar">
                        <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $facettes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $facette): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div wire:key='<?php echo e($facette->id); ?>'>
                                <?php echo $__env->make('components.public.filter-view', [
                                    'title' => $facette->title,
                                    'category' => $facette->category,
                                    'items' => $facette->items,
                                    'selectedItems' => $facette->selectedItems,
                                    'icon' => $facette->icon,
                                    'filterModel' => $facette->filterModel,
                                ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->

                        <div class="widget-boxed">
                            <div class="widget-boxed-body padd-top-40 padd-bot-40 text-center">
                                <div class="help-support">
                                    <i class="ti-headphone-alt font-60 theme-cl mrg-bot-15"></i>
                                    <p>Vous avez une question ? Contactez-nous</p>
                                    <h4 class="mrg-top-0">contact@numrod.fr</h4>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- End Start Sidebar -->

                <!-- Start All Listing -->
                <div class="col-md-8 col-sm-12" wire:key='filterShow'>
                    <!-- Filter option -->
                    <div id="research-zone">
                        <!--[if BLOCK]><![endif]--><?php if($type || $ville || $quartier || $entreprise || $key): ?>
                            <div class="row mrg-0 mrg-bot-10">
                                <div class="col-md-12 mrg-top-10">
                                    <div class="col-md-12" style="margin-left: 0px; padding-left: 0px; display: ''; align-items: center; ">
                                        Recherche : &nbsp;
                                        <!--[if BLOCK]><![endif]--><?php if($key): ?>
                                            <span class="badge height-25 theme-bg" id="key-filter" data-value="<?php echo e($key); ?>">
                                                <?php echo e($key); ?>

                                                <a href="javascript:void(0)" class="text-white selectedOption" wire:click='changeState("<?php echo e($key); ?>", "key", true)'> x </a>
                                            </span> &nbsp;
                                        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                        <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $facettes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $facette): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $facette->selectedItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <span class="badge height-25 theme-bg search-elt" wire:key='sub-facette-filter-<?php echo e($loop->index); ?>'>
                                                    <?php echo e($item); ?>

                                                    <a href="javascript:void(0)" class="text-white selectedOption" wire:click='changeState("<?php echo e($item); ?>", "<?php echo e($facette->category); ?>", true)'> x </a>
                                                </span> &nbsp;
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                                    </div>
                                </div>
                            </div>
                        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                    </div>

                    <div class="row mrg-0">
                        <div class="col-md-6 mrg-top-10">
                            <h5 class="theme-cl-blue">Affichage : <?php echo e($annonces->firstItem()); ?>-<?php echo e($annonces->lastItem()); ?> sur <?php echo e($annonces->total()); ?> résultat trouvé(s)</h5>
                        </div>
                        <div class="col-md-1"></div>
                        <div class="col-md-4">
                            <select id="select-order" class="form-control" style="height: 35px !important; margin-bottom: 0px;" tabindex="-98" wire:model.lazy='sortOrder'>
                                <option value="" disabled>Trier</option>
                                <option value="titre|asc">Titre: A à Z</option>
                                <option value="titre|desc">Titre: Z à A</option>
                                <option value="created_at|asc">Date: Ancien à récent</option>
                                <option value="created_at|desc">Date: Récent à ancien</option>
                            </select>
                        </div>
                        <div class="col-md-1" style="">
                            <a href="javascript:void(0)" class="annonce-share" data-toggle="modal" data-target="#share" data-type="all">
                                <i class="fa fa-share fa-lg" aria-hidden="true"></i>
                            </a>
                        </div>
                    </div>

                    <div class="row mrg-0">
                        <?php echo $__env->make('components.public.share-modal', [
                            'title' => 'Partager cette annonce',
                        ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                        <div class="col-md-12 col-sm-12" wire:loading.delay wire:transition>
                            <?php echo $__env->make('components.public.loader', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        </div>

                        
                        <div id="annonces-zone">
                            <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $annonces; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $annonce): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="col-md-6 col-sm-6" wire:key='<?php echo e(time() . $annonce->id); ?>' id="annonce-<?php echo e($annonce->id); ?>">
                                    <div class="listing-shot grid-style">
                                        <div class="listing-shot-img">
                                            <a href="<?php echo e(route('show', $annonce->slug)); ?>">
                                                <!--[if BLOCK]><![endif]--><?php if($annonce->image): ?>
                                                    <img src="<?php echo e(asset('storage/' . $annonce->imagePrincipale->chemin)); ?>" class="img-responsive" alt="">
                                                <?php else: ?>
                                                    <img src="http://via.placeholder.com/800x800" class="img-responsive" alt="">
                                                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                            </a>
                                        </div>
                                        <div class="listing-shot-caption">
                                            <a href="<?php echo e(route('show', $annonce->slug)); ?>">
                                                <h4 class="theme-cl-blue"><?php echo e($annonce->titre); ?></h4>
                                                <p class="listing-location"><?php echo e($annonce->description_courte); ?></p>
                                            </a>
                                            <!--[if BLOCK]><![endif]--><?php if(Auth::check()): ?>
                                                <!--[if BLOCK]><![endif]--><?php if($annonce->est_favoris): ?>
                                                    <a href="javascript:void(0)" wire:click='updateFavoris(<?php echo e($annonce->id); ?>)'>
                                                        <span class="like-listing style-2"><i class="fa fa-heart-o" aria-hidden="true"></i></span>
                                                    </a>
                                                <?php else: ?>
                                                    <a href="javascript:void(0)" wire:click='updateFavoris(<?php echo e($annonce->id); ?>)'>
                                                        <span class="like-listing alt style-2"><i class="fa fa-heart-o" aria-hidden="true"></i></span>
                                                    </a>
                                                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                            <?php else: ?>
                                                <a href="javascript:void(0)" data-toggle="modal" data-target="#signin" onclick="$('#share').hide()">
                                                    <span class="like-listing alt style-2"><i class="fa fa-heart-o" aria-hidden="true"></i></span>
                                                </a>
                                            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                        </div>
                                        <div class="listing-price-info">
                                            <span class=""><?php echo e($annonce->type); ?> </span>
                                        </div>
                                        <div class="listing-shot-info">
                                            <div class="row extra">
                                                <div class="col-md-12">
                                                    <div class="listing-detail-info">
                                                        
                                                        <span><i class="fa fa-phone" aria-hidden="true"></i> <?php echo e($annonce->entreprise->contact); ?></span>
                                                        <span>
                                                            <i class="fa fa-globe" aria-hidden="true"></i>
                                                            <!--[if BLOCK]><![endif]--><?php if($annonce->entreprise->site_web): ?>
                                                                <?php echo e($annonce->entreprise->site_web); ?>

                                                            <?php else: ?>
                                                                -
                                                            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                                        </span>
                                                    </div>
                                                </div>
                                            </div>

                                            <div class="listing-shot-info rating padd-0">
                                                <?php echo e($annonce->note); ?>

                                                <!--[if BLOCK]><![endif]--><?php for($i = 1; $i <= 5; $i++): ?>
                                                    <i class="<?php echo e($i <= $annonce->note ? 'color' : ''); ?> fa fa-star" aria-hidden="true"></i>
                                                <?php endfor; ?><!--[if ENDBLOCK]><![endif]-->
                                                
                                                <a href="javascript:void(0)" data-toggle="modal" data-target="#share" class="theme-cl annonce-share" style="float: right;"
                                                   data-url="<?php echo e(route('show', $annonce->slug)); ?>"
                                                   data-titre="<?php echo e($annonce->titre); ?>"
                                                   data-image="<?php echo e($annonce->image ? asset('storage/' . $annonce->imagePrincipale->chemin) : 'http://via.placeholder.com/800x800'); ?>"
                                                   data-type="<?php echo e($annonce->type); ?>">
                                                    <i class="fa fa-share theme-cl" aria-hidden="true"></i>
                                                    Partager
                                                </a>
                                            </div>
                                        </div>
                                        <div class="tp-author-basic-info mrg-top-0">
                                            <ul>
                                                <li class="text-center padd-top-10 padd-bot-0">
                                                    <i class="fa fa-eye fa-lg" aria-hidden="true"></i>
                                                    <?php echo e($annonce->nb_vue); ?>

                                                </li>
                                                <li class="text-center padd-top-10 padd-bot-0">
                                                    <i class="fa fa-heart fa-lg" aria-hidden="true"></i>
                                                    <?php echo e($annonce->nb_favoris); ?>

                                                </li>
                                                <li class="text-center padd-top-10 padd-bot-0">
                                                    <i class="fa fa-comment fa-lg" aria-hidden="true"></i>
                                                    <?php echo e($annonce->nb_commentaire); ?>

                                                </li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                        </div>

                        <!--[if BLOCK]><![endif]--><?php if(empty($annonces->count())): ?>
                            <div class="col-md-12 col-sm-12">
                                <div class="listing-shot grid-style" style="padding-top: 50px; padding-bottom: 50px;">
                                    <div class="listing-shot-caption text-center mrg-top-5">
                                        <i class="fa-solid fa-xmark fa-5x" aria-hidden="true"></i> <br>
                                        <h4>Aucune annonce trouvée</h4>
                                        
                                    </div>
                                </div>
                            </div>
                        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                    </div>

                    <div id="annonce-pagination">
                        <?php echo e($annonces->links()); ?>

                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- ================ End Listing In Grid Style ======================= -->
</div>

<?php $__env->startPush('scripts'); ?>
    <script>
        $(document).ready(function() {
            $('.annonce-share').on('click', function() {
                var type = $(this).data('type');
                var text, subject, url, image, annonceType;

                $('#share-annonce-image').show();

                if (type === 'all') {
                    text = decodeURI(window.location.href);
                    subject = $(this).data('titre');
                    url = text;
                    $('#share-annonce-image').hide();
                    $('#annonce-type').text('');
                    $('#annonce-titre').text("Partager la page");
                } else {
                    text = "Salut!%0AJette un œil à l'annonce que j’ai trouvé sur Vamiyi%0ATitre : " + $(this).data('titre') + "%0ALien : " + $(this).data('url') + " ";
                    subject = $(this).data('titre');
                    url = $(this).data('url');
                    image = $(this).data('image');
                    annonceType = $(this).data('type');
                    $('#annonce-titre').text(subject);
                    $('#annonce-image-url').attr('src', image);
                    $('#annonce-type').text(annonceType);
                }

                $('#annonce-email').attr('href', 'mailto:?subject=' + subject + '&body=' + text);
                $('#annonce-url').data('url', url);
                $('#annonce-facebook').attr('href', 'https://www.facebook.com/sharer/sharer.php?u=' + url);
                $('#annonce-whatsapp').attr('href', 'whatsapp://send?text=' + text);
            });

            $('#annonce-url').click(function() {
                var text = $(this).data('url');

                if (!navigator.clipboard) {
                    console.error('Clipboard API not available');
                    return;
                }

                navigator.clipboard.writeText(text).then(function() {
                    $('#copyMessage').hide();
                    $('#copyMessage').fadeIn(500);
                    // $('#copyMessage').show();
                    setTimeout(function() {
                        $('#copyMessage').fadeOut(500);
                        // $('#copyMessage').hide();
                    }, 2000);
                }, function(err) {
                    console.error('Could not copy text: ', err);
                });
            });
        });
    </script>

    <script>
        function filterList(category) {
            // Get the input field and its value
            var filter = normalizeString($('#search-' + category).val());

            // Get the list and its items
            var $li = $('#list-' + category + 's li');

            // Variable to count the number of items displayed
            var count = 0;

            // Loop through the list items and hide those that don't match the filter
            $li.each(function() {
                var txtValue = normalizeString($(this).find('label').text());
                if (txtValue.indexOf(filter) > -1) {
                    $(this).fadeIn(300);
                    count++;
                } else {
                    $(this).fadeOut(300);
                }
            });

            // Get the no results message
            var $noResults = $('#no-' + category + '-results');

            // If no items are displayed, show the no results message
            if (count === 0) {
                $noResults.fadeIn(300);
            } else {
                $noResults.hide(); //fadeOut(300);
            }
        }

        function normalizeString(str) {
            return str.normalize("NFD").replace(/[\u0300-\u036f]/g, "").toUpperCase();
        }

        window.addEventListener('refresh:filter', event => {
            var intervalId = setInterval(function() {
                var categories = [];
                $('ul.price-range').each(function() {
                    if (this.id.startsWith('list-')) {
                        var idWithoutList = this.id.replace('list-', '').slice(0, -1);
                        categories.push(idWithoutList);
                    }
                });

                categories.forEach(function(category) {
                    filterList(category);
                });
                clearInterval(intervalId);
            }, 500);
        });
    </script>

    <script>
        // reset filters
        $(document).ready(function() {
            $('.reset-filters').on('click', function() {
                var url = window.location.href;
                var newUrl = url.split('?')[0];
                window.history.pushState({}, '', newUrl);
            });
        });
    </script>

    <script>
        window.addEventListener('custom:element-removal', event => {
            var ids = event.detail[0].element;
            var perPage = event.detail[0].perPage;
            var key = event.detail[0].key;
            var facette = event.detail[0].facette;

            if (!key) {
                $('#key-filter').fadeOut(300);
            }

            if (facette == 0 && key == '') {
                $('#research-zone').fadeOut(300);
            }

            if (perPage > ids.length) {
                $('#annonce-pagination').fadeOut(300);
            } else {
                $('#annonce-pagination').fadeIn(300);
            }
            // remove element where id is not in ids using js looping on annonces-zone id

            $('#annonces-zone').children().each(function() {
                var annonceId = $(this).attr('id').split('-')[1];
                if (!ids.includes(annonceId)) {
                    $(this).fadeOut(300);
                }
            });
        });













        // $(document).ready(function() {
        //     $('.selectedOption').on('click', function() {
        //         // supprimer l'element pres 2 seconde s'il existe toujours

        //         var intervalId = setInterval(function() {
        //             if ($(this).length > 0) {
        //                 $(this).parent().remove(); //.fadeOut(300);
        //             }
        //             clearInterval(intervalId);
        //         }, 500);
        //     });
        // });
    </script>
<?php $__env->stopPush(); ?>
<?php /**PATH /home/cp1820222p42/public_html/midjo/resources/views/livewire/public/search.blade.php ENDPATH**/ ?>