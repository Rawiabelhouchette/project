<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag; ?>
<?php foreach($attributes->onlyProps(['category']) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $attributes = $attributes->exceptProps(['category']); ?>
<?php foreach (array_filter((['category']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>

<div class="col-md-3 col-sm-12">
    <div class="sidebar">
        <!-- Start: Search By Price -->
        <div class="widget-boxed facette-color" style="padding-bottom: 0px;">
            

            <div class="widget-boxed-body padd-top-10 padd-bot-0">
                <div class="side-list">
                    <ul class="price-range">
                        <li>
                            <a href="<?php echo e(route('accounts.index')); ?>">
                                <span class="custom-checkbox d-block <?php if($category == 0): ?> theme-cl <?php endif; ?>" style="font-size: 18px;">
                                    <i class="fa-solid fa-user <?php if($category == 0): ?> theme-cl <?php endif; ?>"></i> &nbsp;
                                    Compte
                                </span>
                            </a>
                        </li>

                        <li>
                            <a href="<?php echo e(route('accounts.favorite.index')); ?>">
                                <span class="custom-checkbox d-block <?php if($category == 1): ?> theme-cl <?php endif; ?>" style="font-size: 18px;">
                                    <i class="fa-solid fa-star <?php if($category == 1): ?> theme-cl <?php endif; ?>"></i> &nbsp;
                                    Favoris
                                </span>
                            </a>
                        </li>

                        <li>
                            <a href="<?php echo e(route('accounts.comment.index')); ?>">
                                <span class="custom-checkbox d-block <?php if($category == 2): ?> theme-cl <?php endif; ?>" style="font-size: 18px;">
                                    <i class="fa-solid fa-comment <?php if($category == 2): ?> theme-cl <?php endif; ?>"></i> &nbsp;
                                    Commentaires
                                </span>
                            </a>
                        </li>
                    </ul>
                </div>
            </div>
        </div>

    </div>
</div>
<?php /**PATH /home/cp1820222p42/public_html/midjo/resources/views/public/user/menu.blade.php ENDPATH**/ ?>