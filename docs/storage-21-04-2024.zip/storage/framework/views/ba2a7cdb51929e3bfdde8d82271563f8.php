
<?php /**PATH /home/cp1820222p42/public_html/midjo/resources/views/vendor/cookie-consent/index.blade.php ENDPATH**/ ?>