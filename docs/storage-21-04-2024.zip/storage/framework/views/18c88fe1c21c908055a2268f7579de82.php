<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag; ?>
<?php foreach($attributes->onlyProps(['withText' => true, 'color' => '#ff3a72']) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $attributes = $attributes->exceptProps(['withText' => true, 'color' => '#ff3a72']); ?>
<?php foreach (array_filter((['withText' => true, 'color' => '#ff3a72']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>

<div>
    <!--[if BLOCK]><![endif]--><?php if($withText): ?>
        <h5 id="tr-loader" class="text-center mrg-top-5 mrg-bot-0" style="display: block;">
            <div class="lds-dual-ring"></div><br> Chargement...
        </h5>
    <?php else: ?>
        <span class="lds-dual-ring-2"></span>
    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

    <style>
        /* Spinner */
        .lds-dual-ring {
            display: inline-block;
            width: 40px;
            height: 40px;
        }

        .lds-dual-ring:after {
            content: " ";
            display: block;
            width: 24px;
            height: 24px;
            margin: 8px;
            border-radius: 50%;
            border: 4px solid #ff3a72;
            border-color: #ff3a72 transparent;
            animation: lds-dual-ring 1.2s linear infinite;
        }

        @keyframes lds-dual-ring {
            0% {
                transform: rotate(0deg);
            }

            100% {
                transform: rotate(360deg);
            }
        }

        /* 2 */
        .lds-dual-ring-2 {
            display: inline-block;
            /* width: 40px;
            height: 40px; */
        }

        .lds-dual-ring-2:after {
            content: " ";
            display: block;
            width: 20px;
            height: 20px;
            margin: 0px;
            margin-bottom: -5px;
            border-radius: 50%;
            border: 4px solid <?php echo e($color); ?>;
            border-color: <?php echo e($color); ?> transparent <?php echo e($color); ?> transparent;
            animation: lds-dual-ring-2 1.2s linear infinite;
        }

        @keyframes lds-dual-ring-2 {
            0% {
                transform: rotate(0deg);
            }

            100% {
                transform: rotate(360deg);
            }
        }
    </style>
</div>
<?php /**PATH /home/cp1820222p42/public_html/midjo/resources/views/components/public/loader.blade.php ENDPATH**/ ?>