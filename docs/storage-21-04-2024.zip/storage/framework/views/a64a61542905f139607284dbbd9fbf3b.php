<div>
    <!--[if BLOCK]><![endif]--><?php if(Auth::check()): ?>
        <button wire:click='updateFavoris' wire:loading.attr="disabled" class="buttons padd-10 favoris-btn-show" style="background: <?php echo e($isEnabled ? '#ff3a72' : 'white'); ?>; border: 1px solid <?php echo e($isEnabled ? '#ff3a72' : 'grey'); ?>; color: <?php echo e($isEnabled ? 'white' : 'grey'); ?>;">
            <i class="fa fa-heart"></i>
            <span class="hidden-xs">Favoris</span>
        </button>
    <?php else: ?>
        <button data-toggle="modal" data-target="#signin" class="buttons padd-10 favoris-btn-show" style="background: white; border: 1px solid grey; color: grey;">
            <i class="fa fa-heart"></i>
            <span class="hidden-xs">Favoris</span>
        </button>
    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

    <?php $__env->startPush('scripts'); ?>
        <script>
            $(document).ready(function() {
                $('.favoris-btn-show').click(function() {
                    $('#share').hide();
                    $('#modal-gallery').hide();
                });
            });
        </script>
    <?php $__env->stopPush(); ?>
</div>
<?php /**PATH /home/cp1820222p42/public_html/midjo/resources/views/livewire/public/favoris.blade.php ENDPATH**/ ?>