<?php $__env->startSection('content'); ?>
    <!-- ================ Listing Detail Basic Information ======================= -->
    <?php echo $__env->make('public.user.title-banner', ['title' => 'Mon compte'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- ================ End Listing Detail Basic Information ======================= -->

    <section class="show-case">
        <div class="container">
            <div class="row">

                <?php echo $__env->make('public.user.menu', ['category' => 0], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('public.user.account');

$__html = app('livewire')->mount($__name, $__params, 'lw-1805252640-0', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>

            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.public.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/cp1820222p42/public_html/midjo/resources/views/public/user/account.blade.php ENDPATH**/ ?>