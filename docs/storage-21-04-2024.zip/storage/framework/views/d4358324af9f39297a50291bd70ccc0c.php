<div class="col-md-9 col-sm-12">
    <div class="card-body">
        <div class="col-md-12" style="padding: 0px;">
            <!--[if BLOCK]><![endif]--><?php if(session()->has('error')): ?>
                <div class="alert alert-danger alert-dismissable text-center">
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                    <strong>Erreur !</strong>
                    <?php echo e(session()->get('error')); ?>

                </div>
            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
            <?php if(session()->has('success')): ?>
                <div class="alert alert-success alert-dismissable text-center">
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                    <strong>Succès !</strong>
                    <?php echo e(session()->get('success')); ?>

                </div>
            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
        </div>
        <form wire:submit.prevent='update'>
            <?php echo csrf_field(); ?>
            <div class="col-md-12" style="padding: 0px;">
                <div class="add-listing-box edit-info mrg-bot-25 padd-bot-30 padd-top-25">
                    <div class="listing-box-header">
                        <i class="ti-user theme-cl"></i>
                        <h3>Informations personnelles</h3>
                    </div>
                    <div class="text-center">
                        <!--[if BLOCK]><![endif]--><?php if($editInfo || $editPass): ?>
                            <a href="javascript:void(0)" class="btn theme-btn" wire:click='cancel'>Annuler</a>
                        <?php else: ?>
                            <a href="javascript:void(0)" class="btn theme-btn" wire:click='editInformation'>Modifier information</a>
                            <a href="javascript:void(0)" class="btn theme-btn" wire:click='editPassword'>Changer mot de passe</a>
                        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                    </div> <br>

                    <div class="row mrg-r-10 mrg-l-10">
                        <div class="col-sm-6">
                            <label>Nom</label>
                            <input type="text" name="nom" class="form-control" <?php if(!$editInfo): ?> readonly <?php endif; ?> wire:model='nom' required>
                            <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['nom'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="text-danger"><?php echo e($message); ?></span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                        </div>
                        <div class="col-sm-6">
                            <label>Prénom</label>
                            <input type="text" name="prenom" class="form-control" <?php if(!$editInfo): ?> readonly <?php endif; ?> wire:model='prenom' required>
                            <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['prenom'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="text-danger"><?php echo e($message); ?></span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                        </div>
                        <div class="col-sm-6">
                            <label>E-mail</label>
                            <input type="email" name="email" class="form-control" <?php if(!$editInfo): ?> readonly <?php endif; ?> wire:model='email' required>
                            <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="text-danger"><?php echo e($message); ?></span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                        </div>
                        <div class="col-sm-6">
                            <label>Nom d'utilisateur</label>
                            <input type="text" name="username" class="form-control" wire:model='username' <?php if(!$editInfo): ?> readonly <?php endif; ?> required>
                            <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['username'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="text-danger"><?php echo e($message); ?></span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                        </div>
                    </div>
                </div>
            </div>

            <!--[if BLOCK]><![endif]--><?php if($editPass): ?>
                <div wire:transition.fade>
                    <div class="col-md-12" style="padding: 0px;">
                        <div class="add-listing-box opening-day mrg-bot-25 padd-bot-30 padd-top-25">
                            <div class="listing-box-header">
                                <i class="ti-lock theme-cl"></i>
                                <h3>Mot de passe</h3>
                            </div>
                            <div class="row mrg-r-10 mrg-l-10">
                                <div class="col-sm-6">
                                    <label>Ancien mot de passe</label>
                                    <input type="password" wire:model='password_old' class="form-control" placeholder="*********" required>
                                    <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['password_old'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="text-danger"><?php echo e($message); ?></span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                                </div>

                                <div class="col-sm-6">
                                    <label>Nouveau mot de passe</label>
                                    <input type="password" wire:model='password' class="form-control" placeholder="*********" required>
                                    <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="text-danger"><?php echo e($message); ?></span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                                </div>
                            </div>
                            <div class="row mrg-r-10 mrg-l-10">
                                <div class="col-sm-6">
                                    <label>Retaper le nouveau mot de passe</label>
                                    <input type="password" wire:model='password_confirmation' class="form-control" placeholder="*********" required>
                                    <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['password_confirmation'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="text-danger"><?php echo e($message); ?></span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="text-center">
                        <button type="submit" class="btn theme-btn" wire:loading.attr='disabled' wire:target='update'>Mettre a jour</button>
                    </div>
                </div>
            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

            <!--[if BLOCK]><![endif]--><?php if($editInfo): ?>
                <div class="text-center">
                    <button type="submit" class="btn theme-btn" wire:loading.attr='disabled' wire:target='update'>Mettre a jour</button>
                </div>
            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
        </form>
    </div>
</div>

<?php $__env->startPush('scripts'); ?>
    <script>
        window.addEventListener('username:changed', event => {
            $('#navbar_username').text(event.detail[0].username);
        });
    </script>
<?php $__env->stopPush(); ?>
<?php /**PATH /home/cp1820222p42/public_html/midjo/resources/views/livewire/public/user/account.blade.php ENDPATH**/ ?>