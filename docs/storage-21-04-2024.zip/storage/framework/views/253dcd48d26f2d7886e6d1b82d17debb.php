<!-- /. NAV TOP  -->
<nav class="navbar navbar-side">
    <div class="sidebar-collapse">
        <ul class="nav" id="main-menu">

            <li class="<?php echo $__env->yieldContent('dashboard'); ?>">
                <a href="<?php echo e(route('home')); ?>" style="padding-top: 25px;"><i class="fa fa-dashboard" aria-hidden="true"></i>Dashboard</a>
            </li>
            <li class="<?php echo $__env->yieldContent('reference'); ?>">
                <a href="javascript:void(0)"><i class="fa fa-cog" aria-hidden="true"></i>Référence <span class="fa arrow"></span></a>
                <ul class="nav nav-second-level">
                    <li>
                        <a href="<?php echo e(route('references.nom.add')); ?>"><i class="fa fa-circle-o-notch" style="margin-right: 15px;font-size: 16px;"></i>
                            Nom
                        </a>
                    </li>
                    <li>
                        <a href="<?php echo e(route('references.create')); ?>"><i class="fa fa-circle-o-notch" style="margin-right: 15px;font-size: 16px;"></i>
                            Valeur
                        </a>
                    </li>
                    <li>
                        <a href="<?php echo e(route('references.index')); ?>"><i class="fa fa-circle-o-notch" style="margin-right: 15px;font-size: 16px;"></i>
                            Recherche
                        </a>
                    </li>
                </ul>
            </li>

            <li class="<?php echo $__env->yieldContent('localisation'); ?>">
                <a href="javascript:void(0)"><i class="fa fa-map" aria-hidden="true"></i>Localisation <span class="fa arrow"></span></a>
                <ul class="nav nav-second-level">
                    <li>
                        <a href="<?php echo e(route('pays.index')); ?>"><i class="fa fa-circle-o-notch" style="margin-right: 15px;font-size: 16px;"></i>
                            Pays
                        </a>
                    </li>
                    <li>
                        <a href="<?php echo e(route('villes.index')); ?>"><i class="fa fa-circle-o-notch" style="margin-right: 15px;font-size: 16px;"></i>
                            Ville
                        </a>
                    </li>
                    <li>
                        <a href="<?php echo e(route('quartiers.index')); ?>"><i class="fa fa-circle-o-notch" style="margin-right: 15px;font-size: 16px;"></i>
                            Quartier
                        </a>
                    </li>
                    <li>
                        <a href="<?php echo e(route('localisations')); ?>"><i class="fa fa-circle-o-notch" style="margin-right: 15px;font-size: 16px;"></i>
                            Recherche
                        </a>
                    </li>
                </ul>
            </li>

            <li class="<?php echo $__env->yieldContent('compte'); ?>">
                <a href="javascript:void(0)"><i class="fa fa-briefcase" aria-hidden="true"></i>Compte <span class="fa arrow"></span></a>
                <ul class="nav nav-second-level">
                    <li>
                        <a href="<?php echo e(route('users.create')); ?>"><i class="fa fa-circle-o-notch" style="margin-right: 15px;font-size: 16px;"></i>
                            Créer un compte
                        </a>
                    </li>
                    <li>
                        <a href="<?php echo e(route('users.index')); ?>"><i class="fa fa-circle-o-notch" style="margin-right: 15px;font-size: 16px;"></i>
                            Recherche
                        </a>
                    </li>
                </ul>
            </li>
            
            <li class="<?php echo $__env->yieldContent('entreprise'); ?>">
                <a href="javascript:void(0)"><i class="fa fa-city" aria-hidden="true"></i>Entreprise <span class="fa arrow"></span></a>
                <ul class="nav nav-second-level">
                    <li>
                        <a href="<?php echo e(route('entreprises.create')); ?>"><i class="fa fa-circle-o-notch" style="margin-right: 15px;font-size: 16px;"></i>
                            Ajouter une entreprise
                        </a>
                    </li>
                    <li>
                        <a href="<?php echo e(route('entreprises.index')); ?>"><i class="fa fa-circle-o-notch" style="margin-right: 15px;font-size: 16px;"></i>
                            Recherche
                        </a>
                    </li>
                </ul>
            </li>

            <li class="<?php echo $__env->yieldContent('annonce'); ?>">
                <a href="javascript:void(0)"><i class="fa fa-clone" aria-hidden="true"></i>Gestion annonce<span class="fa arrow"></span></a>
                <ul class="nav nav-second-level">
                    <li>
                        <a href="<?php echo e(route('annonces.create')); ?>"><i class="fa fa-circle-o-notch" style="margin-right: 15px;font-size: 16px;"></i>
                            Ajouter une annonce
                        </a>
                    </li>
                    <li>
                        <a href="<?php echo e(route('annonces.index')); ?>"><i class="fa fa-circle-o-notch" style="margin-right: 15px;font-size: 16px;"></i>
                            Recherche
                        </a>
                    </li>
                </ul>
            </li>

            <li class="<?php echo $__env->yieldContent('corbeille'); ?>">
                <a href="javascript:void(0)"><i class="fa fa-trash" aria-hidden="true"></i>Corbeille<span class="fa arrow"></span></a>
                <ul class="nav nav-second-level">
                    <li>
                        <a href="<?php echo e(route('pays.index')); ?>"><i class="fa fa-circle-o-notch" style="margin-right: 15px;font-size: 16px;"></i>
                            Pays
                        </a>
                    </li>
                    <li>
                        <a href="<?php echo e(route('pays.index')); ?>"><i class="fa fa-circle-o-notch" style="margin-right: 15px;font-size: 16px;"></i>
                            Ville
                        </a>
                    </li>
                    <li>
                        <a href="<?php echo e(route('pays.index')); ?>"><i class="fa fa-circle-o-notch" style="margin-right: 15px;font-size: 16px;"></i>
                            Quartier
                        </a>
                    </li>
                    <li>
                        <a href="<?php echo e(route('pays.index')); ?>"><i class="fa fa-circle-o-notch" style="margin-right: 15px;font-size: 16px;"></i>
                            ...
                        </a>
                    </li>

                </ul>
            </li>


        </ul>
    </div>

</nav>
<!-- /. NAV SIDE  -->
<?php /**PATH /home/cp1820222p42/public_html/midjo/resources/views/layout/admin/sidebar.blade.php ENDPATH**/ ?>