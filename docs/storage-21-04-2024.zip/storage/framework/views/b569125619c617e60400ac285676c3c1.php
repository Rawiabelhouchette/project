<div wire:ignore.self id="register" class="modal fade" tabindex="-1" role="dialog" aria-labelledby="myModalLabel3" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">

            <div class="modal-header">
                <h4 id="modalLabel3" class="modal-title"><?php echo e(__('Créer un nouveau compte')); ?></h4>
                <button type="button" class="m-close" data-dismiss="modal" aria-label="Close">
                    <i class="ti-close"></i>
                </button>
            </div>

            <div class="modal-body">

                <div class="wel-back">
                    <h3>Bienvenue! <span class="theme-cl">Nouveau compte ?</span></h3>
                </div>

                <!--[if BLOCK]><![endif]--><?php if($error): ?>
                    <div class="alert-group">
                        <div class="alert alert-danger alert-dismissable" style="text-align: center;">
                            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                            <?php echo e($message); ?>

                        </div>
                    </div>
                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

                <form wire:submit="register()">
                    <?php echo csrf_field(); ?>

                    <div class="row">

                        
                        <div class="col-md-6 col-lg-6 col-xs-6 col-sm-12 form-group">
                            <label for="nom">Nom</label>
                            <input type="text" id="nom" class="form-control" placeholder="Nom" required wire:model="nom">
                        </div>

                        
                        <div class="col-md-6 col-lg-6 col-xs-6 col-sm-12 form-group">
                            <label for="prenom">Prénom</label>
                            <input type="text" id="prenom" class="form-control" placeholder="Prénom" required wire:model="prenom">
                        </div>

                        
                        <div class="col-md-6 col-lg-6 col-xs-6 col-sm-12 form-group">
                            <label for="username">Nom d'utilisateur</label>
                            <input type="text" id="username" class="form-control" placeholder="Nom d'utilisateur" required wire:model="username">
                            <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['username'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="text-danger"><?php echo e($message); ?></span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                        </div>

                        
                        <div class="col-md-6 col-lg-6 col-xs-6 col-sm-12 form-group">
                            <label for="email">Email</label>
                            <input type="email" id="email" class="form-control" placeholder="Email" required wire:model="email">
                            <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="text-danger"><?php echo e($message); ?></span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                        </div>

                        
                        <div class="col-md-6 col-lg-6 col-xs-6 col-sm-12 form-group">
                            <label for="type">Type de compte</label>
                            <select class="form-control" required data-nom="type" wire:model.lazy="type">
                                <option style="font-style: italic; opacity: 0.4;">Choisir</option>
                                <option value="Usager">Usager</option>
                                <option value="Professionnel">Professionnel</option>
                            </select>
                            <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="text-danger"><?php echo e($message); ?></span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                        </div>

                        
                        <div class="col-md-6 col-lg-6 col-xs-6 col-sm-12 form-group">
                            <label for="password">Mot de passe</label>
                            <input type="password" id="password" class="form-control" placeholder="Mot de passe" required wire:model="password">
                        </div>

                        
                        <div class="col-md-6 col-lg-6 col-xs-6 col-sm-12 form-group">
                            <label for="password_confirmation">Rattaper le mot de passe</label>
                            <input type="password" id="password_confirmation" class="form-control" placeholder="Rattaper le mot de passe" required wire:model="password_confirmation">
                            <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['password_confirmation'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="text-danger"><?php echo e($message); ?></span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                        </div>

                    </div>

                    <span class="custom-checkbox d-block">
                        <input id="remember" type="checkbox" name="remember" wire:model="remember">
                        <label for="remember">

                            <?php echo e(__('Se souvenir de moi')); ?>

                        </label>
                    </span>

                    <div class="center">
                        <button id="signup" wire:target='register' wire:loading.attr='disabled' type="submit" class="btn btn-midium theme-btn btn-radius width-200"> Enregistrer </button>
                    </div>

                </form>
            </div>

            <div class="center mrg-top-5">
                <div class="bottom-login text-center">Déjà un compte ? </div>
                <a id="btn-login" href="javascript:void(0)" class="theme-cl"><?php echo e(__('Se Connecter')); ?></a>
            </div>

        </div>
    </div>
</div>

<?php $__env->startPush('scripts'); ?>
    <script>
        $(document).ready(function() {
            $('#type').on('change', function(e) {
                var data = $(this).val();
                console.log(data);
                var nom = $(this).data('nom');
                window.Livewire.find('<?php echo e($_instance->getId()); ?>').set(nom, data);
            });
        });
    </script>
<?php $__env->stopPush(); ?>
<?php /**PATH /home/cp1820222p42/public_html/midjo/resources/views/livewire/public/auth/register.blade.php ENDPATH**/ ?>