<?php
    $typeAnnonce = App\Models\Annonce::pluck('type')
        ->unique()
        ->toArray();
?>

<footer class="footer dark-footer dark-bg">
    
    <div class="container">
        <div class="row">

            <div class="col-md-3 col-sm-6">
                <div class="footer-widget">
                    <h3 class="widgettitle widget-title">IID</h3>
                    <p>L'Institut de l'Information et de la Documentation (IID) est une école qui forme les étudiants aux nouvelles techniques de gestion de l'information et de la documentation.</p>
                    
                </div>
            </div>

            <div class="col-md-3 col-sm-6">
                <div class="footer-widget">
                    <h3 class="widgettitle widget-title">Types d'annonce</h3>
                    <ul class="footer-navigation sinlge">
                        <?php $__currentLoopData = $typeAnnonce; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><a href="javascript:void(0)"><?php echo e($type); ?></a></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            </div>

            <div class="col-md-3 col-sm-6">
                <div class="footer-widget">
                    <div class="textwidget">
                        <h3 class="widgettitle widget-title">Nous retrouver</h3>
                        <div class="address-box">
                            <div class="sing-add">
                                <a style="color: #7f90a7;" href="https://goo.gl/maps/MBJGNz6obPGrMjjH6" target="_blank">
                                    <i class="ti-location-pin"></i>Lomé-Adidogomé
                                </a>
                            </div>
                            <div class="sing-add">
                                <a style="color: #7f90a7;" href="mailto:contact@numrod.fr">
                                    <i class="ti-email"></i>contact@numrod.fr
                                </a>
                            </div>
                            <div class="sing-add">
                                <a style="color: #7f90a7;" href="tel:+22890454591">
                                    <i class="ti-mobile"></i>+228 90 45 45 91
                                </a>
                            </div>
                            <div class="sing-add">
                                <a style="color: #7f90a7;" href="http://numdoc.numrod.fr/" target="_blank">
                                    <i class="ti-world"></i>www.numrod.com
                                </a>
                            </div>
                        </div>
                        <!--<ul class="footer-social">
                            <li><a href="#"><i class="fa fa-facebook"></i></a></li>
                            <li><a href="#"><i class="fa fa-google-plus"></i></a></li>
                            <li><a href="#"><i class="fa fa-twitter"></i></a></li>
                            <li><a href="#"><i class="fa fa-instagram"></i></a></li>
                            <li><a href="#"><i class="fa fa-pinterest"></i></a></li>
                        </ul>-->
                    </div>
                </div>
            </div>

            <div class="col-md-3 col-sm-6">
                <div class="footer-widget">
                    <h3 class="widgettitle widget-title">Nous contacter</h3>
                    <p>Les professionnels restent disponible pour toute demande</p>

                    
                </div>
            </div>
        </div>

    </div>
    <div class="footer-copyright">
        <p>Copyright@
            <?php
                echo date('Y');
            ?>
            propulsé par Numrod <a href="http://www.numrod.com/" title="Numrod" target="_blank">Numrod</a></p>
    </div>
</footer>
<?php /**PATH /home/cp1820222p42/public_html/midjo/resources/views/layout/public/footer.blade.php ENDPATH**/ ?>