<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css" integrity="sha256-p4NxAoJBhIIN+hmNHrzRCf9tD/miZyoHS5obTRR9BMY=" crossorigin="" />
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <!-- ================ Listing Detail Basic Information ======================= -->
    <div class="banner dark-opacity" style="background-image:url(<?php echo e(asset('storage/' . $annonce->imagePrincipale->chemin)); ?>); height: 300px !important; min-height: 300px !important;" data-overlay="8">
        <div class="container">
            <div class="banner-caption">
                <form class="form-verticle" method="GET" action="<?php echo e(route('search')); ?>">
                    <input type="hidden" value="1" name="form_request">
                    <div class="col-md-4 col-sm-4 no-padd">
                        <i class="banner-icon icon-pencil"></i>
                        <input type="text" class="form-control left-radius right-br" placeholder="Mot clé..." name="key">
                    </div>
                    <div class="col-md-3 col-sm-3 no-padd">
                        <div class="form-box">
                            <i class="banner-icon icon-map-pin"></i>
                            <input id="myInput" type="text" class="form-control right-br" placeholder="Localisation..." name="location">
                            <div id="autocomplete-results" class="autocomplete-items"></div>
                        </div>
                    </div>
                    <div class="col-md-3 col-sm-3 no-padd">
                        <div class="form-box">
                            <i class="banner-icon icon-layers"></i>
                            <select class="form-control" name="type[]">
                                <option value="" selected data-placeholder="<?php echo e(__('Tous les types d\'annonce')); ?>" class="chosen-select"><?php echo e(__('Tous les type d\'annonce')); ?></option>
                                <?php $__currentLoopData = $typeAnnonce; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($type); ?>"><?php echo e($type); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                    </div>

                    <div class="col-md-2 col-sm-3 no-padd">
                        <div class="form-box">
                            <button type="submit" class="btn theme-btn btn-default">
                                
                                <?php echo e(__('Rechercher')); ?>

                            </button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
    <!-- ================ End Listing Detail Basic Information ======================= -->

    <!-- ================ Listing Detail Full Information ======================= -->
    <section class="list-detail padd-bot-10 padd-top-30">
        <div class="container">
            <div class="row mrg-bot-40">
                <div class="col-md-6 col-sm-6">
                    <h5>
                        <a href="<?php echo e(route('search')); ?>" title="Revenir à la recherche">
                            <i class="fa fa-fw fa-arrow-left" aria-hidden="true"></i>
                            Revenir à la recherche
                        </a>
                    </h5>
                </div>
                <div class="col-md-6 col-sm-6" style="text-align: right">
                    <h5>
                        <a href="<?php echo e($pagination->previous); ?>" class="btn-default">
                            <i class="fa fa-fw fa-angle-left"></i>
                            Précédent
                        </a>
                        <span class="padd-l-10 padd-r-10 theme-cl">
                            <?php echo e($pagination->position); ?>

                        </span>
                        <a href="<?php echo e($pagination->next); ?>" class="btn-default">
                            Suivant
                            <i class="fa fa-fw fa-angle-right"></i>
                        </a>
                    </h5>
                </div>
            </div>

            <div class="row">
                <!-- Start: Listing Detail Wrapper -->
                <div class="col-md-8 col-sm-8">
                    <div class="detail-wrapper">
                        <div class="detail-wrapper-body">
                            <div class="listing-title-bar">
                                
                                <h3> <?php echo e($annonce->titre); ?> <span class="mrg-l-5 category-tag"><?php echo e($annonce->type); ?></span></h3>
                                <div>
                                    <a href="javascript:void(0)">
                                        <i class="fa fa-building fa-lg" style="color: #ff3a72;"></i>&nbsp;&nbsp;
                                        <?php echo e($annonce->entreprise->nom); ?>

                                    </a><br>
                                    <?php if($annonce->entreprise->site_web): ?>
                                        <a href="<?php echo e($annonce->entreprise->site_web); ?>" target="_blank">
                                            <i class="ti-world" style="color: #ff3a72;"></i>&nbsp;
                                            <?php echo e($annonce->entreprise->site_web); ?>

                                        </a>
                                        <br>
                                    <?php endif; ?>

                                    <?php if($annonce->entreprise->email): ?>
                                        
                                        <a href="javascript:void(0)">
                                            <i class="ti-email" style="color: #ff3a72;"></i>&nbsp;
                                            <?php echo e($annonce->entreprise->email); ?>

                                        </a>
                                        <br>
                                    <?php endif; ?>

                                    

                                    <style>
                                        .li-btn {
                                            background: white;
                                            color: grey;
                                            border: 1px solid grey;
                                            border-radius: 4px;
                                            -webkit-user-select: none;
                                        }

                                        .li-btn.view:hover {
                                            color: gray;
                                        }

                                        .li-btn:hover {
                                            color: #ff3a72;
                                        }

                                        .share-button:hover {
                                            background: #ff3a72 !important;
                                            color: white !important;
                                            border: 1px solid #ff3a72 !important;
                                            border-radius: 4px;
                                        }
                                    </style>
                                    <div class="cover-buttons mrg-top-15" style="float: left;">
                                        <ul>
                                            <li style="padding-left: 0;" class="mrg-r-10">
                                                <span class="buttons li-btn view padd-10">
                                                    <i class="fa fa-eye hidden-xs"></i>
                                                    <span class=""><?php echo e($annonce->nb_vue); ?> vue(s)</span>
                                                </span>
                                            </li>
                                            <li style="padding-left: 0;" class="mrg-r-10">
                                                <span class="buttons li-btn view padd-10">
                                                    <i class="fa fa-comment-o hidden-xs"></i>
                                                    <span class="" id="annonce-commentaire"><?php echo e($annonce->commentaires->count()); ?></span> commentaire(s)
                                                </span>
                                            </li>
                                            <li style="padding-left: 0;" class="mrg-r-10">
                                                <div class="inside-rating buttons listing-rating theme-btn button-plain" style="padd-0 !important; line-height: 0.5; -webkit-user-select: none;">
                                                    <span class="value" id="annonce-note"><?php echo e($annonce->note); ?></span> <sup class="out-of">/ 5</sup>
                                                </div>
                                            </li>
                                            <li style="padding-left: 0;" class="mrg-r-10">
                                                <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('public.favoris', [$annonce]);

$__html = app('livewire')->mount($__name, $__params, 'lw-423589846-0', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
                                            </li>
                                            <li style="padding-left: 0;" class="mrg-r-10">
                                                <button class="buttons padd-10 share-button" data-toggle="modal" data-target="#share" style="background: white; border: 1px solid grey; color: grey;">
                                                    <i class="fa fa-share"></i>
                                                    <span class="hidden-xs">Partager</span>
                                                </button>
                                            </li>
                                        </ul>
                                    </div>

                                    <div class="cover-buttons mrg-top-15" style="float: left;">
                                        <ul>
                                            <style>
                                                .social-network {
                                                    color: #fff;
                                                    display: inline-block;
                                                    font-size: 14px;
                                                    font-weight: 500;
                                                    padding: 6px 15px;
                                                    border-radius: 4px;
                                                    margin-right: 3px;
                                                    margin-bottom: 15px;
                                                    border: 1px solid transparent;
                                                }

                                                .social-network:hover {
                                                    color: #fff;
                                                }

                                                .social-network:visited {
                                                    color: #fff;
                                                }
                                            </style>
                                            
                                            <?php if($annonce->entreprise->instagram): ?>
                                                <li style="padding-left: 0; padding-right: 5px;">
                                                    <a href="<?php echo e($annonce->entreprise->instagram); ?>" class="social-network" target="_blank" style="background-color: #FF3A72"><i class="fa-brands fa-instagram" style="font-size: 17px;"></i> &nbsp;Instagram</a>
                                                </li>
                                            <?php endif; ?>
                                            <?php if($annonce->entreprise->facebook): ?>
                                                <li style="padding-left: 0; padding-right: 5px;">
                                                    <a href="<?php echo e($annonce->entreprise->facebook); ?>" class="social-network" target="_blank" style="background-color: #0866FF"><i class="fa-brands fa-facebook" style="font-size: 17px;"></i> &nbsp;Facebook</a>
                                                </li>
                                            <?php endif; ?>
                                        </ul>
                                    </div>
                                    <br>

                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- Start: Listing Gallery -->
                    <div class="widget-boxed padd-bot-10">
                        <div class="widget-boxed-header">
                            <h4><i class="ti-gallery padd-r-10"></i>Galérie</h4>
                        </div>
                        <div class="widget-boxed-body padd-top-0">
                            <div class="side-list no-border gallery-box">
                                <div class="row mrg-l-5 mrg-r-10 mrg-bot-5">
                                    <div data-toggle="modal" data-id="<?php echo e($annonce->imagePrincipale->id); ?>" data-target="#modal-gallery" class="col-xs-12 col-md-12 padd-0 image-preview" style="margin-bottom: -20px !important; margin-top: -10px !important; padding-left : 3px; padding-right : 3px;">
                                        <div class="listing-shot grid-style">
                                            <div class="" style="display: flex; justify-content: center; align-items: center; height: 220px; background:url(<?php echo e(asset('storage/' . $annonce->imagePrincipale->chemin)); ?>); background-size: cover; background-position: center;">
                                            </div>
                                        </div>
                                    </div>
                                    <?php $__currentLoopData = $annonce->galerie; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if($key < 3): ?>
                                            <div data-toggle="modal" data-id="<?php echo e($image->id); ?>" data-target="#modal-gallery" class="col-xs-12 col-md-3 padd-0 padd-3 image-preview">
                                                <div class="listing-shot grid-style">
                                                    <div class="" style="display: flex; justify-content: center; align-items: center; height: 120px; background:url(<?php echo e(asset('storage/' . $image->chemin)); ?>); background-size: cover; background-position: center;">
                                                    </div>
                                                </div>
                                            </div>
                                        <?php elseif($key == 3): ?>
                                            <div data-toggle="modal" data-id="<?php echo e($image->id); ?>" data-target="#modal-gallery" class="col-xs-12 col-md-3 padd-0 padd-3 image-preview">
                                                <div class="listing-shot grid-style">
                                                    <div style="position: relative; display: flex; justify-content: center; align-items: center; height: 120px; background:url(<?php echo e(asset('storage/' . $image->chemin)); ?>); background-size: cover; background-position: center;">
                                                        <div style="position: absolute; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0, 0, 0, 0.5); display: flex; justify-content: center; align-items: center;">
                                                            
                                                            <div style="color: white; font-size: 20px;">
                                                                +<?php echo e(count($annonce->galerie) - 4); ?>

                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        <?php else: ?>
                                        <?php break; ?>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- End: Listing Gallery -->

                <div class="detail-wrapper">
                    <div class="detail-wrapper-header">
                        <h4><i class="ti-info-alt padd-r-10"></i>Description
                        </h4>
                    </div>
                    <div class="detail-wrapper-body">
                        <p>
                            <?php echo e($annonce->description ?? 'Aucune description disponible'); ?>

                        </p>
                    </div>
                </div>

                <div class="tab style-1 mrg-bot-40" role="tabpanel">
                    <!-- Nav tabs -->
                    <ul class="nav nav-tabs" role="tablist">
                        <li role="presentation" class="active"><a href="#information" aria-controls="information" role="tab" data-toggle="tab">Information</a></li>
                        <li role="presentation"><a href="#equipement" aria-controls="equipement" role="tab" data-toggle="tab">Equipements</a></li>
                    </ul>
                    <!-- Tab panes -->
                    <div class="tab-content tabs">
                        <div role="tabpanel" class="tab-pane fade in active" id="information">
                            <?php echo e($annonce->annonceable->caracteristiques); ?>

                        </div>
                        <div role="tabpanel" class="tab-pane fade" id="equipement">
                            <?php $__empty_1 = true; $__currentLoopData = $annonce->referenceDisplay(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <?php if(count($value) > 0): ?>
                                    <div class="row">
                                        <div class="col-md-12">
                                            <strong class="" style="text-transform: uppercase;"><?php echo e($key); ?></strong>
                                        </div>
                                        <div class="detail-wrapper-body padd-bot-10">
                                            <ul class="detail-check">
                                                <?php $__empty_2 = true; $__currentLoopData = $value; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $equipement): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_2 = false; ?>
                                                    <div class="col-xs-12 col-md-4 padd-l-0">
                                                        <li style="width: 100%;"><?php echo e($equipement); ?></li>
                                                    </div>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_2): ?>
                                                    <span class="text-center">
                                                        Aucun équipement disponible
                                                    </span>
                                                <?php endif; ?>
                                            </ul>
                                        </div>
                                    </div>
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <div class="col-md-12">
                                    Aucun équipement disponible
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>

                <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('public.comment', [$annonce]);

$__html = app('livewire')->mount($__name, $__params, 'lw-423589846-1', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>

            </div>
            <!-- End: Listing Detail Wrapper -->

            <!-- Sidebar Start -->
            <div class="col-md-4 col-sm-12">
                <div class="sidebar">
                    <!-- Start: Listing Location -->
                    <div class="widget-boxed padd-bot-10">
                        <div class="widget-boxed-header">
                            <h4><i class="ti-location-pin padd-r-10"></i>Localisation</h4>
                        </div>
                        <div class="widget-boxed-body padd-top-5">
                            <div class="side-list no-border">
                                <ul>
                                    <li>Pays : <strong><?php echo e($annonce->entreprise->quartier->ville->pays->nom); ?> </strong></li>
                                    <li>Ville : <strong><?php echo e($annonce->entreprise->quartier->ville->nom); ?> </strong></li>
                                    <li>Quartier : <strong><?php echo e($annonce->entreprise->quartier->nom); ?> </strong></li>
                                    <li>
                                        <div id="map" class="full-width" style="height:200px;"></div>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div>
                    <!-- End: Listing Location -->

                    <!-- Start: Opening hour -->
                    <div class="widget-boxed padd-bot-10">
                        <div class="widget-boxed-header">
                            <h4><i class="ti-time padd-r-10"></i>Heures d'ouverture</h4>
                        </div>
                        <div class="widget-boxed-body">
                            <div class="side-list">
                                <ul>
                                    <?php $__currentLoopData = $annonce->entreprise->heure_ouvertures; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $ouverture): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li><?php echo e($key); ?> <span><?php echo e($ouverture); ?></span></li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            </div>
                        </div>
                    </div>
                    <!-- End: Opening hour -->
                </div>
            </div>
            <!-- End: Sidebar Start -->
        </div>
    </div>

</section>
<!-- ================ Listing Detail Full Information ======================= -->

<?php echo $__env->make('public.gallery', [
    'galerie' => $annonce->galerie,
    'couverture' => $annonce->imagePrincipale,
], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php echo $__env->make('components.public.share-modal-alt', [
    'title' => 'Partager cette annonce',
    'annonce' => $annonce,
], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<style>
    @keyframes pulse {
        0% {
            transform: scale(1);
        }

        50% {
            transform: scale(0.9);
        }

        100% {
            transform: scale(1);
        }
    }

    .pulse {
        animation: pulse 1s infinite;
    }
</style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js" integrity="sha256-20nQCchB9co0qIjJZRGuk2/Z9VM+kNiyxNV1lvTlZBo=" crossorigin=""></script>

<script>
    var mymap = L.map('map').setView([8.6195, 0.8248], 6);

    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
        maxZoom: 19
    }).addTo(mymap);

    var marker;

    var lon = <?php echo e($annonce->entreprise->longitude); ?>;
    var lat = <?php echo e($annonce->entreprise->latitude); ?>;
    if (marker) {
        mymap.removeLayer(marker);
    }

    marker = L.marker([lat, lon]).addTo(mymap);
    mymap.setView([lat, lon], 12);
</script>

<script>
    $(document).ready(function() {
        $('.image-preview').click(function() {
            $('#share').hide();
            var id = $(this).data('id');
            $('#image-' + id).addClass('pulse');
            setTimeout(() => {
                $('#image-' + id).removeClass('pulse');
            }, 2000);
        });
    });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.public.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/cp1820222p42/public_html/midjo/resources/views/public/show.blade.php ENDPATH**/ ?>