<div class="navbar navbar-inverse navbar-fixed-top">
    <div class="col-md-6">
        <div class="containelr" style="margin-left: 5px; margin-right: 0px !important;">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".sidebar-collapse">
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="<?php echo e(route('accueil')); ?>" target="_blank"><img src="<?php echo e(asset('assets/img/logo-vamiyi-by-numrod.png')); ?>" height="100%" xd alt=""></a>
            </div>
        </div>
    </div>
    <div class="col-md-3"></div>
    <div class="col-md-3" style="text-align: right;">

        <div class="navbar-collapse" style="margin-right: 15px;">
            <ul class="nav navbar-top-links navbar-right">
                
                <!-- /.dropdown -->
                
                <!-- /.dropdown -->
                <li class="dropdown">
                    <a class="dropdown-toggle" data-toggle="dropdown" href="#">
                        <img src="<?php echo e(asset('assets/img/user.jpg')); ?>" class="img-responsive img-circle" alt="user">
                    </a>
                    <ul class="dropdown-menu dropdown-user">
                        <li><a href="#"><i class="fa fa-user fa-fw"></i> User Profile</a>
                        </li>
                        <li><a href="#"><i class="fa fa-gear fa-fw"></i> Settings</a>
                        </li>
                        <li class="divider"></li>
                        <li>
                            <a href="<?php echo e(route('logout')); ?>"><i class="fa fa-sign-out fa-fw"></i> Logout</a>
                        </li>
                    </ul>
                    <!-- /.dropdown-user -->
                </li>
                <!-- /.dropdown -->
            </ul>
            <!-- /.navbar-top-links -->
        </div>
    </div>
</div>
<?php /**PATH /home/cp1820222p42/public_html/midjo/resources/views/layout/admin/navbar.blade.php ENDPATH**/ ?>